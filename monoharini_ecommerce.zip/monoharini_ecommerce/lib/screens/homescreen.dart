import 'package:flutter/material.dart';
import 'package:monoharini_ecommerce/widgets/search_textfield.dart';
import '../widgets/home_header.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final TextEditingController searchController;

  @override
  void initState() {
    super.initState();
    searchController = TextEditingController();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const HomeHeader(),
                const SizedBox(height: 18),
                SearchTextField(
                  controller: searchController,
                  hintText: 'Search any Product..',
                  onChanged: (value) {
                    debugPrint('Typing: $value');
                  },
                  onMicTap: () {
                    debugPrint('Mic tapped');
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
